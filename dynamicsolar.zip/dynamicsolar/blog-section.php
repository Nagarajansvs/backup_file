<div class="row-articles">
                        <div class="container">
                            <div class="col-md-12">
                                <div class="themesflat-spacer clearfix" data-desktop="175" data-mobile="120" data-smobile="120"></div>
                            </div>
                            <div class="themesflat-headings style-2 wow fadeInUp article">
                                <h1 class="heading">OUR INSIGHTS & ARTICLES</h1>
                            </div>
                            <div class="owl-carousel owl-theme" data-item="3" data-item2="2">
                                <div class="item acticle wow fadeInUp">
                                    <div class="img">
                                        <div class="img-overlay"></div>
                                        <img src="assets/img/shortcode/article/article-1.jpg" alt="Image" />
                                    </div>
                                    <ul>
                                        <li><a class="date-articles" href="#">28 JANUARY, 2020</a></li>
                                    </ul>
                                    <div class="box-acticle">
                                        <a href="blog-detail.html" class="link-articles">
                                            MAURIS NEQUE NISIIBUS NON <br />
                                            ELEMENTUM
                                        </a>
                                        <p class="content">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt</p>
                                        <i class="line"></i>
                                        <a href="blog-detail.html" class="btn-read-more">READ MORE</a>
                                    </div>
                                </div>
                                <div class="item acticle wow fadeInDown">
                                    <div class="img">
                                        <div class="img-overlay"></div>
                                        <img src="assets/img/shortcode/article/article-2.jpg" alt="Image" />
                                    </div>
                                    <ul>
                                        <li><a class="date-articles" href="blog-detail.html">28 JANUARY, 2020</a></li>
                                    </ul>
                                    <div class="box-acticle">
                                        <a href="blog-detail.html" class="link-articles">
                                            MAURIS NEQUE NISIIBUS NON <br />
                                            ELEMENTUM
                                        </a>
                                        <p class="content">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt</p>
                                        <i class="line"></i>
                                        <a href="blog-detail.html" class="btn-read-more">READ MORE</a>
                                    </div>
                                </div>
                                <div class="item acticle wow fadeInUp">
                                    <div class="img">
                                        <div class="img-overlay"></div>
                                        <img src="assets/img/shortcode/article/article-3.jpg" alt="Image" />
                                    </div>
                                    <ul>
                                        <li><a class="date-articles" href="blog-detail.html">28 JANUARY, 2020</a></li>
                                    </ul>
                                    <div class="box-acticle">
                                        <a href="blog-detail.html" class="link-articles">
                                            MAURIS NEQUE NISIIBUS NON <br />
                                            ELEMENTUM
                                        </a>
                                        <p class="content">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt</p>
                                        <i class="line"></i>
                                        <a href="blog-detail.html" class="btn-read-more">READ MORE</a>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>