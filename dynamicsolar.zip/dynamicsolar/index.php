<?php
  include "header.php";
?>


                <div id="main-content-home" class="site-main clearfix">
                    <div class="rev_slider_wrapper fullwidthbanner-container">
                        <div id="rev-slider1" class="rev_slider fullwidthabanner">
                            <ul>
                                <li data-transition="random">
                                    <div
                                        class="tp-img-1"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['-420','0','-20','0']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['0','-100','-100','0']"
                                        data-whitespace="normal"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <img src="assets/img/slider/slider-1_.png" alt="Image" data-bgposition="center center" data-no-retina />
                                    </div>
                                    <div
                                        class="tp-caption tp-resizeme tp-img"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['615','400','400','0']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['-25','0','0','-200']"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="300"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <img src="assets/img/slider/slider-1.png" alt="Image" data-bgposition="center center" data-no-retina />
                                    </div>

                                    <div
                                        class="tp-caption tp-resizeme text-green font-heading font-weight-500"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['0','34','34','15']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['-190','-160','-160','0']"
                                        data-fontsize="['16','16','16','14']"
                                        data-lineheight="['20','18','18','16']"
                                        data-width="full"
                                        data-height="none"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="300"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <span class="heading-tittle">CONSEQUAT VEL PORTA</span>
                                    </div>
                                    <div
                                        class="tp-caption tp-resizeme text-black font-heading font-weight-400"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['0','34','34','15']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['-97','-67','-67','73']"
                                        data-fontsize="['72','62','62','42']"
                                        data-lineheight="['60','50','50','40']"
                                        data-width="full"
                                        data-height="none"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="400"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <span class="tittle1">
                                            TURN UP THE BRIGHTNESS <br />
                                            TURN UP THE SOLAR POWER.
                                        </span>
                                    </div>
                                    <div
                                        class="tp-caption tp-resizeme line"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['0','34','34','0']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['-10','10','10','150']"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="500"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    ></div>
                                    <div
                                        class="tp-caption tp-resizeme text-black font-heading font-weight-400"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['0','34','34','15']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['44','64','64','204']"
                                        data-fontsize="['16','16','16','14']"
                                        data-lineheight="['30','20','20','16']"
                                        data-width="full"
                                        data-height="none"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="600"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        Fonsetetur sadipscing elitr, sed diam nonumy eirmod tempor <br />
                                        invidunt ut labore et dolore magna aliquyam
                                    </div>
                                    <div
                                        class="tp-caption"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['2','34','34','15']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['140','160','160','300']"
                                        data-width="full"
                                        data-height="none"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="700"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <a href="contact.html" class="btn get-a-quote">Get A Quote</a>
                                    </div>
                                </li>

                                <li data-transition="random">
                                    <div
                                        class="tp-img-1"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['-420','0','-20','0']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['0','0','0','0']"
                                        data-responsive_offset="on"
                                    >
                                        <img src="assets/img/slider/slider-1_.png" alt="Image" data-bgposition="center center" data-no-retina />
                                    </div>
                                    <div
                                        class="tp-caption tp-resizeme tp-img"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['615','400','400','0']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['-25','0','0','-200']"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="300"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <img src="assets/img/slider/slider-1.png" alt="Image" data-bgposition="center center" data-no-retina />
                                    </div>

                                    <div
                                        class="tp-caption tp-resizeme text-green font-heading font-weight-500"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['0','34','34','15']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['-190','-160','-160','0']"
                                        data-fontsize="['16','16','16','14']"
                                        data-lineheight="['20','18','18','16']"
                                        data-width="full"
                                        data-height="none"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="300"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <span class="heading-tittle">CONSEQUAT VEL PORTA</span>
                                    </div>
                                    <div
                                        class="tp-caption tp-resizeme text-black font-heading font-weight-400"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['0','34','34','15']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['-97','-67','-67','73']"
                                        data-fontsize="['72','62','62','42']"
                                        data-lineheight="['60','50','50','40']"
                                        data-width="full"
                                        data-height="none"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="400"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <span class="tittle1">
                                            TURN UP THE BRIGHTNESS <br />
                                            TURN UP THE SOLAR POWER.
                                        </span>
                                    </div>
                                    <div
                                        class="tp-caption tp-resizeme line"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['0','34','34','0']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['-10','10','10','150']"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="500"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    ></div>
                                    <div
                                        class="tp-caption tp-resizeme text-black font-heading font-weight-400"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['0','34','34','15']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['44','64','64','204']"
                                        data-fontsize="['16','16','16','14']"
                                        data-lineheight="['30','20','20','16']"
                                        data-width="full"
                                        data-height="none"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="600"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        Fonsetetur sadipscing elitr, sed diam nonumy eirmod tempor <br />
                                        invidunt ut labore et dolore magna aliquyam
                                    </div>
                                    <div
                                        class="tp-caption"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['2','34','34','15']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['140','160','160','300']"
                                        data-width="full"
                                        data-height="none"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="700"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <a href="contact.html" class="btn get-a-quote">Get A Quote</a>
                                    </div>
                                </li>

                                <li data-transition="random">
                                    <div
                                        class="tp-img-1"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['-420','0','-20','0']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['0','0','0','0']"
                                        data-responsive_offset="on"
                                    >
                                        <img src="assets/img/slider/slider-1_.png" alt="Image" data-bgposition="center center" data-no-retina />
                                    </div>
                                    <div
                                        class="tp-caption tp-resizeme tp-img"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['615','400','400','0']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['-25','0','0','-200']"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="300"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <img src="assets/img/slider/slider-1.png" alt="Image" data-bgposition="center center" data-no-retina />
                                    </div>

                                    <div
                                        class="tp-caption tp-resizeme text-green font-heading font-weight-500"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['0','34','34','15']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['-190','-160','-160','0']"
                                        data-fontsize="['16','16','16','14']"
                                        data-lineheight="['20','18','18','16']"
                                        data-width="full"
                                        data-height="none"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="300"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <span class="heading-tittle">CONSEQUAT VEL PORTA</span>
                                    </div>
                                    <div
                                        class="tp-caption tp-resizeme text-black font-heading font-weight-400"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['0','34','34','15']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['-97','-67','-67','73']"
                                        data-fontsize="['72','62','62','42']"
                                        data-lineheight="['60','50','50','40']"
                                        data-width="full"
                                        data-height="none"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="400"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <span class="tittle1">
                                            TURN UP THE BRIGHTNESS <br />
                                            TURN UP THE SOLAR POWER.
                                        </span>
                                    </div>
                                    <div
                                        class="tp-caption tp-resizeme line"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['0','34','34','0']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['-10','10','10','150']"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="500"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    ></div>
                                    <div
                                        class="tp-caption tp-resizeme text-black font-heading font-weight-400"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['0','34','34','15']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['44','64','64','204']"
                                        data-fontsize="['16','16','16','14']"
                                        data-lineheight="['30','20','20','16']"
                                        data-width="full"
                                        data-height="none"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="600"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        Fonsetetur sadipscing elitr, sed diam nonumy eirmod tempor <br />
                                        invidunt ut labore et dolore magna aliquyam
                                    </div>
                                    <div
                                        class="tp-caption"
                                        data-x="['left','left','left','center']"
                                        data-hoffset="['2','34','34','15']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['140','160','160','300']"
                                        data-width="full"
                                        data-height="none"
                                        data-whitespace="normal"
                                        data-transform_idle="o:1;"
                                        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                                        data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                        data-mask_in="x:0px;y:[100%];"
                                        data-mask_out="x:inherit;y:inherit;"
                                        data-start="700"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-responsive_offset="on"
                                    >
                                        <a href="contact.html" class="btn get-a-quote">Get A Quote</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>


                    <!-- <?php
                        include "slider.php";
                    ?> -->
                
                    <div class="row-service">
                        <div class="service">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="themesflat-spacer clearfix" data-desktop="114" data-mobile="60" data-smobile="60"></div>
                                        <div class="themesflat-headings style-1 text-center wow fadeInUp clearfix">
                                            <h1 class="heading">SERVICES FOR YOU</h1>
                                            <p class="sub-heading">
                                                Fonsetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut<br />
                                                labore et dolore magna aliquyam
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="service-inner" class="container">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-service wow fadeInDown">
                                        <div class="service-inner-img">
                                            <div class="img-overlay"></div>
                                            <img src="assets/img/shortcode/service/service-1.jpg" alt="Image" />
                                        </div>
                                        <div class="service-inner-text">
                                            <div class="icon zingbox-icon-sola-plant"></div>
                                            <div class="text-wrap">
                                                <h3 class="heading"><a href="#">Solar Power Plant</a></h3>
                                                <div class="sep clearfix"></div>
                                                <p class="sub-heading">We have On-grid and Off-grid solar system to back up energy and keep your home solar-powered.</p>
                                            </div>
                                            <a href="#" class="service-read-more">Read More <i class="fa fa-arrow-right"></i> </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-service active wow fadeInUp">
                                        <div class="service-inner-img">
                                            <div class="img-overlay"></div>
                                            <img src="assets/img/shortcode/service/service-2.jpg" alt="Image" />
                                        </div>
                                        <div class="service-inner-text">
                                            <div class="icon zingbox-icon-traffic-light"></div>
                                            <div class="text-wrap">
                                                <h3 class="heading"><a href="#">Solar Pumping Systems</a></h3>
                                                <div class="sep clearfix"></div>
                                                <p class="sub-heading">Having operated by Solar PV system, our generates power and pumps water for irrigation or other purposes.</p>
                                                <a href="#" class="service-read-more">Read More <i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-service wow fadeInDown">
                                        <div class="service-inner-img">
                                            <div class="img-overlay"></div>
                                            <img src="assets/img/shortcode/service/service-3.jpg" alt="Image" />
                                        </div>
                                        <div class="service-inner-text">
                                            <div class="icon zingbox-icon-enegy"></div>
                                            <div class="text-wrap">
                                                <h3 class="heading"><a href="#">Solar Home UPS</a></h3>
                                                <div class="sep clearfix"></div>
                                                <p class="sub-heading">To keep your home or commercial place free from power losses, our solar-powered inverters can be the best choice.</p>
                                                <a href="#" class="service-read-more">Read More <i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row-counter">
                        <img src="assets/img/shortcode/counter/bg-counter.png" alt="Image" />
                        <div class="container">
                            <div class="row clearfix">
                                <div class="col-md-12">
                                    <div class="themesflat-spacer clearfix" data-desktop="120" data-mobile="60" data-smobile="60"></div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="box-counter wow fadeInUp">
                                        <div class="themesflat-counter style-1 align-center clearfix">
                                            <div class="counter-item">
                                                <div class="inner">
                                                    <div class="text-wrap box1">
                                                        <span class="icon zingbox-icon-author"></span>
                                                        <div class="number-wrap"><span class="number" data-speed="3000" data-to="10000" data-inviewport="yes" data-delimitor="1">10000</span><span class="suffix">,000</span></div>
                                                        <h3 class="heading margin-right-6">Dedicated Employees</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="box-counter wow fadeInDown">
                                        <div class="themesflat-counter style-1 align-center clearfix">
                                            <div class="counter-item">
                                                <div class="inner">
                                                    <div class="text-wrap">
                                                        <span class="icon zingbox-icon-book"></span>
                                                        <div class="number-wrap"><span class="number" data-speed="3000" data-to="5000" data-inviewport="yes">5000</span><span class="suffix">+</span></div>
                                                        <h3 class="heading margin-right-6">Happy Customers</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="box-counter wow fadeInUp">
                                        <div class="themesflat-counter style-1 align-center clearfix">
                                            <div class="counter-item">
                                                <div class="inner">
                                                    <div class="text-wrap">
                                                        <span class="icon zingbox-icon-diamond"></span>
                                                        <div class="number-wrap"><span class="number" data-speed="3000" data-to="500" data-inviewport="yes">500</span><span class="suffix">+</span></div>
                                                        <h3 class="heading margin-right-8">Successful Projects</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="box-counter wow fadeInDown">
                                        <div class="themesflat-counter style-1 align-center clearfix">
                                            <div class="counter-item">
                                                <div class="inner">
                                                    <div class="text-wrap">
                                                        <span class="icon zingbox-icon-clock"></span>
                                                        <div class="number-wrap"><span class="number" data-speed="3000" data-to="150" data-inviewport="yes">150</span><span class="suffix"></span></div>
                                                        <h3 class="heading margin-right-10">Branches</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row clearfix">
                                <div class="col-md-12">
                                    <div class="themesflat-spacer clearfix" data-desktop="115" data-mobile="60" data-smobile="60"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row-work">
                        <img class="bg-img" src="assets/img/shortcode/work/bg-work.png" alt="Image" />
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="themesflat-headings style-2 text-center wow fadeInUp clearfix">
                                        <h1 class="heading">OUR WORK PROCESS</h1>
                                        <p class="sub-heading">From home to offices, with the increased usage electricity-powered devices, energy-efficiency is the need and solar power systems serve it while offering biggest benefits.</p>
                                    </div>
                                    <div class="themesflat-spacer clearfix" data-desktop="55" data-mobile="35" data-smobile="35"></div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="box-work wow fadeInUp">
                                                <img src="assets/img/shortcode/work/work-1.png" alt="Image" />
                                                <div class="text-wrap">
                                                    <h6 class="heading">Renewable</h6>
                                                    <p class="sub-heading">Energy produced using solar panels are renewable as it is created from the sun source.</p>
                                                    <a href="#" class="btn-read-more">Read More <i class="fa fa-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="box-work wow fadeInDown">
                                                <img src="assets/img/shortcode/work/work-2.png" alt="Image" />
                                                <div class="text-wrap">
                                                    <h6 class="heading">Low Operating Costs</h6>
                                                    <p class="sub-heading">The process of generating electricity from sunlight requires no fuel or extra costs.</p>
                                                    <a href="#" class="btn-read-more">Read More <i class="fa fa-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="box-work wow fadeInUp">
                                                <img src="assets/img/shortcode/work/work-3.png" alt="Image" />
                                                <div class="text-wrap">
                                                    <h6 class="heading">Low Operating Costs</h6>
                                                    <div class="sep clearfix"></div>
                                                    <p class="sub-heading">No use of fuel means no emission of environment-polluting gases like carbon dioxide.</p>
                                                    <a href="#" class="btn-read-more">Read More <i class="fa fa-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="themesflat-spacer clearfix" data-desktop="122" data-mobile="60" data-smobile="60"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row-request">
                        <div class="col-md-6"><img class="img-left" src="assets/img/shortcode/request/request-left.jpg" alt="Image" /></div>
                        <div class="col-md-6"><img class="img-right" src="assets/img/shortcode/request/request-right.png" alt="Image" /></div>
                        <div class="container-fluid">
                            <div class="row-request-inner">
                                <div class="container">
                                    <div class="row-request-right wow fadeInUp">
                                        <div class="ok">
                                            <div class="row">
                                                <h1 class="heading-request">REQUEST A QUOTE</h1>
                                            </div>
                                            <div class="row-request-right-inner">
                                                <div class="request-right-inner-left">
                                                    <div><input class="text" type="text" placeholder="Full Name" /></div>
                                                    <div><input class="text" type="text" placeholder="Email Address" /></div>
                                                    <div class="tittle-select"><span>Solar system type?</span></div>
                                                    <div>
                                                        <select class="select">
                                                            <option value="0">System Installer</option>
                                                            <option value="1">system type 1</option>
                                                            <option value="2">system type 2</option>
                                                        </select>
                                                    </div>
                                                    <div class="tittle-select"><span>Solar panels place?</span></div>
                                                    <div>
                                                        <select class="select bottom-select">
                                                            <option value="0">Imperdiet orci</option>
                                                            <option value="1">place 1</option>
                                                            <option value="2">place 2</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="request-right-inner-right">
                                                    <div><input class="text" type="text" placeholder="Phone Number" /></div>
                                                    <div>
                                                        <select class="select">
                                                            <option value="0">Choose services</option>
                                                            <option value="1">service 1</option>
                                                            <option value="2">service 2</option>
                                                        </select>
                                                    </div>
                                                    <div class="tittle-select"><span>Solar panels place?</span></div>
                                                    <div>
                                                        <select class="select">
                                                            <option value="0">Odio metus</option>
                                                            <option value="1">place 1</option>
                                                            <option value="2">place 2</option>
                                                        </select>
                                                    </div>
                                                    <div class="tittle-select"><span>Materials on your roof?</span></div>
                                                    <div>
                                                        <select class="select">
                                                            <option value="0">Maecenas ligula</option>
                                                            <option value="1">Maecenas ligula</option>
                                                            <option value="2">Maecenas ligula</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="btn-submit"><input class="submit" type="submit" value="Submit Request" /></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row-question">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="themesflat-spacer clearfix" data-desktop="122" data-mobile="60" data-smobile="60"></div>
                                </div>
                                <div class="col-lg-6 col-md-8">
                                    <div class="themesflat-headings style-2 question wow fadeInUp clearfix">
                                        <h1 class="heading">WHAT OUR CLIENTS SAY</h1>
                                        <p class="sub-heading">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore</p>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-4">
                                    <div class="image-switch">
                                        <img class="image" src="assets/img/shortcode/question/question-right.jpg" alt="Image" />
                                    </div>
                                </div>
                            </div>
                            <div class="row-question-slider">
                                <div class="col-md-8">
                                    <div class="swiper-container mySwiper">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide item1 wow fadeInUp">
                                                <div class="box-question">
                                                    <span class="fa fa-quote-left"></span>
                                                    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut</p>
                                                    <div class="author">
                                                        <img src="assets/img/shortcode/question/question-left-1.png" alt="Image" />
                                                        <div class="author-content">
                                                            <div><a class="name-author" href="index.html#">EUGENE FREEMAN</a></div>
                                                            <div><span>Tincidunt</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-slide item2 wow fadeInDown">
                                                <div class="box-question box2">
                                                    <span class="fa fa-quote-left"></span>
                                                    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut</p>
                                                    <div class="author">
                                                        <img src="assets/img/shortcode/question/question-left-2.png" alt="Image" />
                                                        <div class="author-content">
                                                            <div><a class="name-author" href="index.html#">KELLY COLEMAN</a></div>
                                                            <div><span>Nulla nec</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-slide item1 wow fadeInUp">
                                                <div class="box-question">
                                                    <span class="fa fa-quote-left"></span>
                                                    <p>
                                                        Lorem ipsum dolor sit amet,<br />
                                                        consetetur sadipscing elitr, sed diam<br />
                                                        nonumy eirmod tempor invidunt ut
                                                    </p>
                                                    <div class="author">
                                                        <img src="assets/img/shortcode/question/question-left-1.png" alt="Image" />
                                                        <div class="author-content">
                                                            <div><a class="name-author" href="index.html#">EUGENE FREEMAN</a></div>
                                                            <div><span>Tincidunt</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-pagination"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row-articles">
                        <div class="container">
                            <div class="col-md-12">
                                <div class="themesflat-spacer clearfix" data-desktop="175" data-mobile="120" data-smobile="120"></div>
                            </div>
                            <div class="themesflat-headings style-2 wow fadeInUp article">
                                <h1 class="heading">OUR INSIGHTS & ARTICLES</h1>
                            </div>
                            <div class="owl-carousel owl-theme" data-item="3" data-item2="2">
                                <div class="item acticle wow fadeInUp">
                                    <div class="img">
                                        <div class="img-overlay"></div>
                                        <img src="assets/img/shortcode/article/article-1.jpg" alt="Image" />
                                    </div>
                                    <ul>
                                        <li><a class="date-articles" href="#">28 JANUARY, 2020</a></li>
                                    </ul>
                                    <div class="box-acticle">
                                        <a href="blog-detail.html" class="link-articles">
                                            MAURIS NEQUE NISIIBUS NON <br />
                                            ELEMENTUM
                                        </a>
                                        <p class="content">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt</p>
                                        <i class="line"></i>
                                        <a href="blog-detail.html" class="btn-read-more">READ MORE</a>
                                    </div>
                                </div>
                                <div class="item acticle wow fadeInDown">
                                    <div class="img">
                                        <div class="img-overlay"></div>
                                        <img src="assets/img/shortcode/article/article-2.jpg" alt="Image" />
                                    </div>
                                    <ul>
                                        <li><a class="date-articles" href="blog-detail.html">28 JANUARY, 2020</a></li>
                                    </ul>
                                    <div class="box-acticle">
                                        <a href="blog-detail.html" class="link-articles">
                                            MAURIS NEQUE NISIIBUS NON <br />
                                            ELEMENTUM
                                        </a>
                                        <p class="content">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt</p>
                                        <i class="line"></i>
                                        <a href="blog-detail.html" class="btn-read-more">READ MORE</a>
                                    </div>
                                </div>
                                <div class="item acticle wow fadeInUp">
                                    <div class="img">
                                        <div class="img-overlay"></div>
                                        <img src="assets/img/shortcode/article/article-3.jpg" alt="Image" />
                                    </div>
                                    <ul>
                                        <li><a class="date-articles" href="blog-detail.html">28 JANUARY, 2020</a></li>
                                    </ul>
                                    <div class="box-acticle">
                                        <a href="blog-detail.html" class="link-articles">
                                            MAURIS NEQUE NISIIBUS NON <br />
                                            ELEMENTUM
                                        </a>
                                        <p class="content">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt</p>
                                        <i class="line"></i>
                                        <a href="blog-detail.html" class="btn-read-more">READ MORE</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="themesflat-spacer clearfix" data-desktop="120" data-mobile="60" data-smobile="60"></div>
                            </div>
                        </div>
                    </div>
                </div>

<?php
  include "footer.php";
?>