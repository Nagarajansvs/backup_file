

<style>
  .get-a-quote .modal .modal-dialog 
  {
    max-width: 400px;
    margin: 30px auto;
  }
  .get-a-quote .modal
  {
      margin-top: 20rem;
  }
  .get-a-quote .modal .modal-header h4
  {
    font-family: teko, sans-serif;
    color: #000;
    font-weight: 400;
    line-height: 1;
    font-size: 35px;
  }
  .get-a-quote .modal button.close
  {
    font-family: zingbox-icon;
    font-size: 30px;
  }
  .get-a-quote .modal button.close:hover, .get-a-quote .modal button.close:focus
  {
    background:transparent;
  }
  .get-a-quote .modal .enquiry-footer-btn .btn-read-more
  {
    font-size: 14px;
    padding: 10px 20px;
    width: 100%;
  }
  .get-a-quote .modal .modal-dialog .btn-read-more {
    background-color: #57b33e;
    padding: 15px 20px !important;
    color: #fff;
    font-size: 15px;
    font-weight: 700;
    border-radius: 5px;
    border:none;
}



.widget.widget_get-a-quote {
    margin-bottom: 0px;
}
.widget.widget_get-a-quote .widget-title {
    margin-bottom: 24px;
}
.widget.widget_get-a-quote .widget-title span {
    padding: 10px 0 0;
}
.widget.widget_get-a-quote input {
    border-radius: 5px;
}
.widget.widget_get-a-quote .name,
.widget.widget_get-a-quote .email {
    margin-bottom: 4px;
}
.widget.widget_get-a-quote .name input {
    padding: 20px 0 18px 22px;
}
.widget.widget_get-a-quote .name::after {
    content: "\e97c";
    font-family: zingbox-icon;
    color: #df1e08;
    font-size: 14px;
    position: absolute;
    right: 31px;
    top: 35px;
    display:none !important;
}
.widget.widget_get-a-quote .email input {
    padding: 20px 0 18px 22px;
}
.widget.widget_get-a-quote .email::after {
    content: "\e97a";
    font-family: zingbox-icon;
    color: #df1e08;
    font-size: 12px;
    position: absolute;
    right: 29px;
    top: 125px;
    display:none !important;
}
.widget.widget_get-a-quote .message input {
    padding: 11px 0 80px 22px;
}
.widget.widget_get-a-quote .message::after {
    content: "\e97b";
    font-family: zingbox-icon;
    color: #df1e08;
    font-size: 14px;
    position: absolute;
    right: 29px;
    top: 210px;
    display:none !important;
}
.widget.widget_get-a-quote .message {
    margin-bottom: 12px;
}
.widget.widget_get-a-quote .btn-send {
    background-color: #57b33e;
    padding: 15px 50px;
    color: #fff;
    font-size: 15px;
    font-weight: 700;
    border-radius: 5px;
}
.widget.widget_get-a-quote .btn-send:hover {
    background-color: #ff7029;
}
</style>

  <div class="get-a-quote">
    <!-- The Modal -->
    <div class="modal" id="myModal">
      <div class="modal-dialog">
        <div class="modal-content">
        
          <!-- Modal Header -->
          <div class="modal-header">
            <h4 class="modal-title">Get a Quote</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          
          <!-- Modal body -->
          <div class="modal-body">
            <form>
              <div class="widget widget_get-a-quote">
                <div class="name"><input type="text" placeholder="Name" /></div>
                <div class="tel"><input type="tel" placeholder="Phone" /></div>
                <div class="email"><input type="text" placeholder="Email" /></div>
                <div class="message"><input type="text" placeholder="Message" /></div>
                
                <div class="enquiry-footer-btn">
                  <div class="row">
                    <div class="col-sm-12">
                      <button type="button" class="btn-read-more">Send</button>  
                    </div>
                  </div>
                </div>

              </div>
            </form>
          </div>
          
          <!-- Modal footer -->          
        </div>
      </div>
    </div>
  </div>


<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
