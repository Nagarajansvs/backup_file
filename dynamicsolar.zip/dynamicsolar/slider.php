


<link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<style>

</style>


<div class="banner-container">
        <ul class="ul-width" style="width: 16240px;">
            <li>
                <a href="#"><img src="https://unsplash.it/874/639?image=529" alt=""></a>
                <span class="overlay"><h1>Hello</h1></span>
            </li>
            <li>
                <a href="#"><img src="https://unsplash.it/874/639?image=545" alt=""></a>   
                <span class="overlay"><h1>Hello</h1></span>
            </li>
            <li>
                <a href="#"><img src="https://unsplash.it/874/639?image=541" alt=""></a>   
                <span class="overlay"><h1>Hello</h1></span>
            </li>            
        </ul>
        <div class="clear"></div>
</div>


<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script>
    // JavaScript Document

	$(window).load(function(){
		var sum=0;
		$('.banner-container li img').each(function(){ 
			sum += $(this).width();
		});
		$('.banner-container ul').width(sum);
	});
	$(function(){
		var winWidth = $(".banner-container").width();
		var ulWidthCount = 0;
		ulWidthCount = $('.banner-container li').size();
		$(".banner-container li").width(winWidth/ulWidthCount);
		$(".banner-container li").hover(function(){			
			ulWidthCount = $('.banner-container li').size();
			var imgWidth = $(this).find("img").width();
			var bannerLi = winWidth - imgWidth;
			var remWidth = ulWidthCount - 1;
			var appWidth = bannerLi/remWidth;
			$(".banner-container li").stop(true, false).animate({width: appWidth},700);
			$(this).stop(true, false).animate({width: imgWidth},700);
			$(this).find("span.overlay").stop(true, false).fadeOut();
		}, function(){
			$(this).animate({width: winWidth/ulWidthCount},700);
			$(".banner-container li").animate({width:winWidth/ulWidthCount},700);
			$(this).find("span.overlay").fadeIn();
		});	
	});
</script>