<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
    <head>
        <meta charset="utf-8" />
        <title>Dynamicsolar</title>
        <meta name="author" content="themesflat.com" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <link rel="stylesheet" type="text/css" href="assets/style.css" />
        <link rel="stylesheet" type="text/css" href="assets/zingbox-icon.css" />
        <link rel="stylesheet" href="https://cdn.rawgit.com/daneden/animate.css/v3.1.0/animate.min.css" />
        <script src="https://cdn.rawgit.com/matthieua/WOW/1.0.1/dist/wow.min.js"></script>
        <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
        <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
        <link rel="stylesheet" href="assets/owlcarousel/assets/owl.carousel.min.css" />
        <link rel="stylesheet" href="assets/owlcarousel/assets/owl.theme.default.min.css" />
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="assets/owlcarousel/owl.carousel.min.js"></script>
        <script src="assets/js/owlcarousel.js"></script>
        <link rel="shortcut icon" href="assets/img/favicon.ico" />
        <link rel="apple-touch-icon-precomposed" href="assets/img/favicon.ico" />
    </head>
    <body class="sidebar-right header-style-2 topbar-style-1 menu-has-search header-fixed">
        <div id="wrapper" class="animsition">
            <div id="page" class="">
                <div id="site-header-wrap">
                    <div id="top-bar">
                        <div id="top-bar-inner" class="container">
                            <div class="top-bar-inner-wrap">
                                <div class="top-bar-content">
                                    <div class="inner">
                                        <span class="location content">Gandhi Rd,Tambaram West,Tambaram</span>
                                        <span class="envelope content">
                                        <a href="Mailto:info@dynamicsolar.in">info@dynamicsolar.in</a>
                                        </span>
                                    </div>
                                </div>
                                <div class="top-bar-socials">
                                    <div class="inner">
                                        <span class="icons">
                                            <a href="#"><i class="fa fa-facebook"></i></a>
                                            <a href="#"><i class="fa fa-twitter"></i></a>
                                            <a href="#"><i class="fa fa-google-plus"></i></a>
                                            <a href="#"><i class="fa fa-instagram"></i></a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <header id="site-header">
                        <div id="site-header-inner" class="container">
                            <div class="wrap-inner clearfix">
                                <div id="site-logo" class="clearfix">
                                    <div id="site-logo-inner">
                                        <a href="index.php" rel="home" class="main-logo">
                                            <img src="assets/img/logo.png" alt="Zingbox" data-retina="assets/img/logo.png" />
                                        </a>
                                    </div>
                                </div>
                                <div class="mobile-button">
                                    <span></span>
                                </div>
                                <nav id="main-nav" class="main-nav">
                                    <ul id="menu-primary-menu" class="menu">
                                        <li class="menu-item menu-item-has-children">
                                            <a class="active" href="index.php">Home</a>
                                        </li>
                                        <li class="menu-item menu-item-has-children">
                                            <a class="" href="about.php">About Us</a>
                                        </li>
                                        <li class="menu-item menu-item-has-children">
                                            <a class="down" href="">Products</a>
                                            <ul class="sub-menu">
                                                <li class="menu-item"><a href="solar-power-plant.php">Solar Power Plant</a></li>
                                                <li class="menu-item"><a href="solor-water-heater.php">Solar Water Heater</a></li>
                                                <li class="menu-item"><a href="solor-water-pumping-system.php">Solar Water Pumping Systems</a></li>
                                                <li class="menu-item"><a href="solor-street-light.php">Solar Street Lights</a></li>
                                                <li class="menu-item"><a href="solor-home-ups.php">Solar Home UPS</a></li>
                                                <li class="menu-item"><a href="inverter-home-ups.php">Inverter Home UPS</a></li>
                                                <li class="menu-item"><a href="battery.php">Battery</a></li>
                                                <li class="menu-item"><a href="online-ups.php">Online UPS</a></li>
                                                <li class="menu-item"><a href="ro-systems.php">RO Systems</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item menu-item-has-children">
                                            <a class="" href="project.php">Projects</a>
                                        </li>
                                        <li class="menu-item menu-item-has-children">
                                            <a class="" href="blog.php">Blog</a>
                                        </li>
                                        <li class="menu-item menu-item-has-children">
                                            <a href="contact.php">Contact</a>
                                        </li>
                                    </ul>
                                </nav>
                                <div id="header-get-a-quote">
                                    <a href="contact.php" class="header-get-a-quote-icon">Get A Quote</a>
                                </div>
                            </div>
                        </div>
                    </header>
                </div>