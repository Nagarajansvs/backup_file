
<?php
include "header.php";
?>

<div id="main-content-home" class="site-main clearfix">
                    <div id="header-banner" class="header-banner clearfix">
                        <div class="header-banner-overlay"></div>
                        <div id="header-banner-inner" class="container clearfix">
                            <div class="header-banner-inner-wrap">
                                <div class="blog-standar-start">
                                    <h1 class="blog-standar-start1">PROJECT DETAILS</h1>
                                </div>
                                <h2 class="blog-standar-end">
                                    <a href="index.html" class="blog-standar-end">Home</a> |
                                    <span class="blog-standar-end">Project Details</span>
                                </h2>
                            </div>
                        </div>
                    </div>

                    <div class="container">
                        <div class="themesflat-spacer clearfix" data-desktop="120" data-mobile="60" data-smobile="60"></div>
                        <div class="project-detail-content">
                            <div class="heading">
                                <img src="assets/img/shortcode/project-detail/img-project-detail.jpg" alt="Image" />
                                <div class="top-information">
                                    <div class="project-infor">
                                        <h2>Project Info</h2>
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt</p>
                                    </div>
                                    <div class="category">
                                        <h2>Category</h2>
                                        <p>Curabitur elit metus</p>
                                    </div>
                                    <div class="date">
                                        <h2>Date</h2>
                                        <p>April 24, 2021</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="infor-of-project">
                            <div class="themesflat-spacer clearfix" data-desktop="144" data-mobile="285" data-smobile="60"></div>
                            <h1>INFORMATION OF PROJECT</h1>
                            <p>
                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea
                                rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore
                                magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.
                            </p>
                            <p>
                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea
                                rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem
                            </p>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <img class="img-project-detail" src="assets/img/shortcode/project-detail/infor-project1.jpg" alt="Image" />
                            </div>
                            <div class="col-md-4">
                                <img class="img-project-detail" src="assets/img/shortcode/project-detail/infor-project2.jpg" alt="Image" />
                            </div>
                            <div class="col-md-4">
                                <img class="img-project-detail" src="assets/img/shortcode/project-detail/infor-project3.jpg" alt="Image" />
                            </div>
                        </div>
                        <div class="themesflat-spacer clearfix" data-desktop="35" data-mobile="35" data-smobile="35"></div>
                        <div class="our-main-goal">
                            <div class="row">
                                <div class="col-md-12"><h1>OUR MAIN GOALS</h1></div>
                                <div class="col-md-6">
                                    <p class="margin-top-4">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores
                                        et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut
                                        labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna
                                    </p>
                                </div>
                                <div class="col-md-6">
                                    <div class="our-main-goal-inner">
                                        <div class="content one">
                                            <a class="title" href="service-detail.html">Quality Control System</a>
                                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</p>
                                        </div>
                                        <div class="content two margin-left-16">
                                            <a class="title" href="service-detail.html">Highly Professional Staff</a>
                                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</p>
                                        </div>
                                    </div>
                                    <div class="our-main-goal-inner">
                                        <div class="content tree">
                                            <a class="title" href="service-detail.html">Quality Control System</a>
                                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</p>
                                        </div>
                                        <div class="content four margin-left-16">
                                            <a class="title" href="service-detail.html">Highly Professional Staff</a>
                                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="themesflat-spacer clearfix" data-desktop="45" data-mobile="45" data-smobile="45"></div>
                        <div class="post-tag-project">
                            <div class="tag">
                                <a class="black" href="project-detail.html#">Black</a>
                                <a class="aid" href="project-detail.html#">Aid</a>
                                <a class="green" href="project-detail.html#">Green</a>
                            </div>
                            <div class="socical-icon">
                                <span> Share :</span>
                                <a class="facebook" href="project-detail.html#"><i class="fa fa-facebook"></i></a>
                                <a class="twitter" href="project-detail.html#"><i class="fa fa-twitter"></i></a>
                                <a class="pinterest" href="project-detail.html#"><i class="fa fa-pinterest-p"></i></a>
                            </div>
                        </div>

                        <div class="row-articles">
                            <div class="col-md-12">
                                <div class="themesflat-spacer clearfix" data-desktop="137" data-mobile="60" data-smobile="60"></div>
                            </div>
                            <div class="themesflat-headings style-2 wow fadeInUp article">
                                <h1 class="heading project">RELATED PROJECTS</h1>
                            </div>
                            <div class="swiper-container style-2 mySwiper3">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide wow fadeInUp">
                                        <div class="box-img wow fadeInUp">
                                            <div class="img">
                                                <img src="assets/img/shortcode/img/img-5.jpg" alt="Image" />
                                            </div>
                                            <div class="row-image-content style-2">
                                                <div class="row-image-content-text">
                                                    <div><span class="tittle">NEC VEHICULA </span></div>
                                                    <div><a href="project-detail.html" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                                </div>
                                                <div class="row-image-content-link">
                                                    <a href="project-detail.html" class="icon"><i class="fa fa-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide wow fadeInDown">
                                        <div class="box-img active wow fadeInUp">
                                            <div class="img">
                                                <img src="assets/img/shortcode/img/img-1.jpg" alt="Image" />
                                            </div>
                                            <div class="row-image-content style-2">
                                                <div class="row-image-content-text">
                                                    <div><span class="tittle">NEC VEHICULA </span></div>
                                                    <div><a href="project-detail.html" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                                </div>
                                                <div class="row-image-content-link">
                                                    <a href="project-detail.html" class="icon"><i class="fa fa-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide wow fadeInUp">
                                        <div class="box-img wow fadeInUp">
                                            <div class="img">
                                                <img src="assets/img/shortcode/img/img-2.jpg" alt="Image" />
                                            </div>
                                            <div class="row-image-content style-2">
                                                <div class="row-image-content-text">
                                                    <div><span class="tittle">NEC VEHICULA </span></div>
                                                    <div><a href="project-detail.html" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                                </div>
                                                <div class="row-image-content-link">
                                                    <a href="project-detail.html" class="icon"><i class="fa fa-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="arrow-left-project"></div>
                                    <div class="arrow-right-project"></div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="themesflat-spacer clearfix" data-desktop="90" data-mobile="60" data-smobile="60"></div>
                            </div>
                        </div>
                    </div>
                </div>

<?php
include "footer.php";
?>
