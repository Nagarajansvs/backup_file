<?php
require 'PHPMailerAutoload.php';

$mail = new PHPMailer;
//$mail->SMTPDebug = 4;   
                            // Enable verbose debug output

    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $comment = $_POST['comment'];

    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'nagarajansvs@gmail.com';                 // SMTP username
    $mail->Password = 'qbxmwarxmvgnpmin';                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    // TCP port to connect to

    $mail->setFrom($email, $name);
    $mail->addAddress('nagarajansvs@gmail.com', 'ashvatthacapital');     // Add a recipient

    $mail->isHTML(true);                                  // Set email format to HTML

    $mail->Subject = $subject;
    $mail->Body    = 'NAME :'.$name.'<br>'.'Email :'.$email .'<br>'.'Subject :'.$subject.'<br>'.'Subject :'.$comment.'<br>';

    if(!$mail->send()) {
        $_SESSION['message'] = 'failed';
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    } else {
        // echo 'Message has been sent';
        $_SESSION['message'] = 'success';
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }
   
