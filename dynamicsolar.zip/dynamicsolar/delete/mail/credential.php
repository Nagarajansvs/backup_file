<?php 
	/*Update credentials*/
	define('EMAIL', 'nagarajansvs@gmail.com');
	define('PASS', 'nagarajan');
 ?>