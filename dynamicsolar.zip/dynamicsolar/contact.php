
<?php
  include "header.php";
?>

<div id="main-content-home" class="site-main clearfix">
    <div id="header-banner" class="header-banner clearfix">
        <div class="header-banner-overlay"></div>
        <div id="header-banner-inner" class="container clearfix">
            <div class="header-banner-inner-wrap">
                <div class="blog-standar-start">
                    <h1 class="blog-standar-start1">CONTACT</h1>
                </div>
                <h2 class="blog-standar-end">
                    <a href="index.php" class="blog-standar-end">Home</a> |
                    <span class="blog-standar-end">Contact</span>
                </h2>
            </div>
        </div>
    </div>

    <div class="themesflat-spacer clearfix" data-desktop="120" data-mobile="60" data-smobile="60"></div>
    <div class="write-a-message">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="themesflat-headings contact style-2 wow fadeInUp clearfix">
                        <a class="get-in-touch" href="contact.html#">Get in touch</a>
                        <h1 class="heading">WRITE US A MESSAGE</h1>
                        <p class="sub-heading">The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog,</p>
                    </div>
                    <ul class="socical-icon">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
                <div class="col-md-8">
              
                <form role="form" action="" method="post" id="contact-form">

                    <div class="form-submit">
                        <div class="infor wow fadeInUp">
                            <input type="text" placeholder="Full Name" required/>
                            <input type="text" placeholder="Phone Number" required/>
                        </div>
                        <div class="infor wow fadeInUp">
                            <input type="text" placeholder="Email Address" required/>
                            <input type="text" placeholder="Subject" required/>
                        </div>
                        <div class="message wow fadeInUp">
                            <input type="text" placeholder="Your Massege" required/>
                        </div>
                        <div class="send">
                            <button class="message-submit" type="submit">Send Message</button>
                        </div>
                    </div>
                </form>

                </div>
            </div>
        </div>
    </div>
    <div class="themesflat-spacer clearfix" data-desktop="220" data-mobile="60" data-smobile="60"></div>
</div>

<?php
  include "footer.php";
?>
