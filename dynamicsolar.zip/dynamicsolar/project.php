<?php
  include "header.php";
?>

<div id="main-content-home" class="site-main clearfix">
    <div id="header-banner" class="header-banner clearfix">
        <div class="header-banner-overlay"></div>
        <div id="header-banner-inner" class="container clearfix">
            <div class="header-banner-inner-wrap">
                <div class="blog-standar-start">
                    <h1 class="blog-standar-start1">PROJECT</h1>
                </div>
                <h2 class="blog-standar-end">
                    <a href="index.php" class="blog-standar-end">Home</a> |
                    <span class="blog-standar-end">Project</span>
                </h2>
            </div>
        </div>
    </div>

    <div class="row-case-study style-2">
        <div class="container">
            <div class="themesflat-spacer clearfix" data-desktop="120" data-mobile="60" data-smobile="60"></div>
            <div class="tab flat-tab">
                <ul class="tab-title menu-tab text-center">
                    <li class="item-title active"><span>All</span></li>
                    <li class="item-title"><span>Cells</span></li>
                    <li class="item-title"><span>Inverter</span></li>
                    <li class="item-title"><span>Batteries</span></li>
                    <li class="item-title"><span>Stabilizers</span></li>
                    <li class="item-title"><span>Online UPS</span></li>
                </ul>
                <div class="tab-content-wrap clearfix">
                    <div class="tab-content">
                        <div class="item-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-5.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2 active">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-1.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-2.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-3.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-4.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-5.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-6.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-7.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-8.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="item-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-4.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2 active">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-2.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-6.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-3.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-5.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-1.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-7.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-3.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-8.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="item-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-5.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2 active">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-1.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-2.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-3.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-4.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-5.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-6.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-7.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-8.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="item-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-4.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2 active">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-2.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-6.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-3.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-5.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-1.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-7.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-3.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-8.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="item-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-5.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2 active">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-1.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-2.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-3.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-4.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-5.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-6.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-7.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-8.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="item-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-4.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2 active">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-2.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-6.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-3.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-5.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-1.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-7.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-3.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box-img style-2">
                                        <div class="img">
                                            <img src="assets/img/shortcode/img/img-8.jpg" alt="Image" />
                                        </div>
                                        <div class="row-image-content">
                                            <div class="row-image-content-text">
                                                <div><span class="tittle">NEC VEHICULA </span></div>
                                                <div><a href="#" class="heading-tittle">MAXIMUS LIBERO ORNARE </a></div>
                                            </div>
                                            <div class="row-image-content-link">
                                                <a href="#" class="icon"><i class="fa fa-arrow-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="load-more text-center">
                    <a class="btn-load-more" href="#">Load More</a>
                </div>
            </div>
            <div class="themesflat-spacer clearfix" data-desktop="135" data-mobile="135" data-smobile="135"></div>
        </div>
    </div>
</div>

<?php
  include "footer.php";
?>