<?php
  include "header.php";
?>

<div id="header-banner" class="header-banner clearfix">
    <div class="header-banner-overlay"></div>
    <div id="header-banner-inner" class="container clearfix">
        <div class="header-banner-inner-wrap">
            <div class="blog-standar-start">
                <h1 class="blog-standar-start1">BLOG STANDARD</h1>
            </div>
            <h2 class="blog-standar-end">
                <a href="index.html" class="blog-standar-end">Home</a> |
                <span class="blog-standar-end">Blog Standard</span>
            </h2>
        </div>
    </div>
</div>

<div id="main-content" class="site-main clearfix">
    <div id="content-wrap" class="container">
        <div id="site-content" class="site-content clearfix">
            <div id="inner-content" class="inner-content-wrap">
                
                <article class="hentry data-effect">

                    <div class="row">
                        <div class="col-sm-4">
                            <div class="post-media clerafix">
                            <a href="blog-detail.html"><img src="assets/img/post/post-1.jpg" alt="Image" /></a>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="post-content-wrap">
                                <div class="post-meta">
                                    <div class="post-meta-content">
                                        <div class="post-meta-content-inner">
                                            <span class="post-by-author item">
                                                user<span class="inner"><a href="blog.html#"> BY ADMIN</a></span>
                                            </span>
                                            <span class="post-date item">
                                                <span class="inner"><span class="entry-date">28 JANUARY, 2020</span></span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <h6 class="post-title">
                                    <span class="post-title-inner">
                                        <a href="blog-detail.html">LOREM IPSUM DOLOR SIT AMET, CONSETETUR SADIPSCING </a>
                                    </span>
                                </h6>
                                <div class="post-content">
                                    <p>
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo
                                        dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
                                    </p>
                                </div>
                                <div class="post-read-more">
                                    <div class="post-link">
                                        <a href="blog-detail.html">READ MORE</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </article>

                <article class="hentry data-effect">

                    <div class="row">
                        <div class="col-sm-4">
                            <div class="post-media clerafix">
                            <a href="blog-detail.html"><img src="assets/img/post/post-1.jpg" alt="Image" /></a>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="post-content-wrap">
                                <div class="post-meta">
                                    <div class="post-meta-content">
                                        <div class="post-meta-content-inner">
                                            <span class="post-by-author item">
                                                user<span class="inner"><a href="blog.html#"> BY ADMIN</a></span>
                                            </span>
                                            <span class="post-date item">
                                                <span class="inner"><span class="entry-date">28 JANUARY, 2020</span></span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <h6 class="post-title">
                                    <span class="post-title-inner">
                                        <a href="blog-detail.html">LOREM IPSUM DOLOR SIT AMET, CONSETETUR SADIPSCING </a>
                                    </span>
                                </h6>
                                <div class="post-content">
                                    <p>
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo
                                        dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
                                    </p>
                                </div>
                                <div class="post-read-more">
                                    <div class="post-link">
                                        <a href="blog-detail.html">READ MORE</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </article>
                
                
                
            </div>
        </div>
        
    </div>
</div>

<?php
  include "footer.php";
?>